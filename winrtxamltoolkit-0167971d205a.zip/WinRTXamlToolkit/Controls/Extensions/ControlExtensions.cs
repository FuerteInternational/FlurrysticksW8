﻿namespace WinRTXamlToolkit.Controls.Extensions
{
    /// <summary>
    /// Extensions that apply to Control classes.
    /// </summary>
    public static class ControlExtensions
    {
    }
}
